from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Tuple

import yaml


# -----------------------------
# Path helpers
# -----------------------------
def find_connectors_root(start: Path) -> Path:
    """
    Walk upwards from 'start' until we find a folder named 'connectors'.
    """
    for p in [start, *start.parents]:
        c = p / "connectors"
        if c.is_dir():
            return c.resolve()
    raise RuntimeError(f"Could not find 'connectors' folder by walking up from: {start}")


def load_db(db_path: Path) -> List[dict]:
    return json.loads(db_path.read_text(encoding="utf-8"))


def build_index(db: List[dict]) -> Dict[Tuple[str, str], dict]:
    """
    Index by (uid, case) because uid can repeat across cases.
    """
    idx: Dict[Tuple[str, str], dict] = {}
    for r in db:
        uid = r.get("uid")
        case = r.get("case")
        if uid is None or case is None:
            continue
        idx[(uid, case)] = r
    return idx


def load_process_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


# -----------------------------
# Core calc
# -----------------------------
def Q_blackbox_kW(process: dict, idx: Dict[Tuple[str, str], dict]) -> Tuple[float, float, float, List[dict]]:
    """
    Returns:
      Qdot_kW = Hout - Hin  (positive = net heat into box)
      Hin_kW, Hout_kW
      details: per-stream rows
    """
    if "streams" not in process or not isinstance(process["streams"], list):
        raise KeyError("process YAML must contain a top-level key 'streams' as a list")

    Hin = 0.0
    Hout = 0.0
    details: List[dict] = []

    for s in process["streams"]:
        uid = s["uid"]
        case = s["case"]
        role = s["role"]
        name = s.get("name", uid)
        mdot = float(s["mdot_kg_s"])

        key = (uid, case)
        if key not in idx:
            raise KeyError(f"Stream not found in DB for uid={uid!r}, case={case!r} (stream={name!r})")

        rec = idx[key]
        h = rec["properties"]["h_kJ_kg"]
        if h is None:
            raise ValueError(f"Missing h_kJ_kg for uid={uid!r}, case={case!r} (stream={name!r})")

        H = mdot * float(h)  # kJ/s = kW

        row = {
            "name": name,
            "role": role,
            "uid": uid,
            "case": case,
            "mdot_kg_s": mdot,
            "h_kJ_kg": float(h),
            "mdot_h_kW": H,
            "state": {
                "T_K": rec["state"]["T_K"],
                "P_Pa": rec["state"]["P_Pa"],
            },
            "phase": rec["properties"].get("phase"),
        }
        details.append(row)

        if role == "in":
            Hin += H
        elif role == "out":
            Hout += H
        else:
            raise ValueError(f"Invalid role={role!r} for stream {name!r}. Use 'in' or 'out'.")

    Qdot = Hout - Hin
    return Qdot, Hin, Hout, details


# -----------------------------
# Runner over folders
# -----------------------------
def find_process_yamls(process_root: Path, yaml_name: str = "process_def.yaml") -> List[Path]:
    """
    Finds all process_def.yaml under process_root (recursively).
    This allows you to have multiple per folder if you ever want.
    """
    return sorted(process_root.rglob(yaml_name))


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    # Adjust if you want: this script lives inside integration-dwpy/process/
    here = Path(__file__).resolve().parent
    process_root = here  # .../integration-dwpy/process

    # Your folders (as requested)
    subfolders = ["biodigester", "cheese", "cip", "evap", "mesost", "past", "rivella"]

    connectors_root = find_connectors_root(process_root)
    db_path = connectors_root / "connector_database.json"
    if not db_path.exists():
        raise FileNotFoundError(f"connector_database.json not found: {db_path}")

    db = load_db(db_path)
    idx = build_index(db)

    # output folder
    out_root = process_root / "results"
    ensure_dir(out_root)

    timestamp = datetime.now(timezone.utc).isoformat()

    summary_rows: List[dict] = []
    failures: List[dict] = []

    for sf in subfolders:
        folder = process_root / sf
        if not folder.is_dir():
            failures.append({"folder": str(folder), "error": "folder not found"})
            continue

        yamls = find_process_yamls(folder, yaml_name="process_def.yaml")
        if not yamls:
            failures.append({"folder": str(folder), "error": "process_def.yaml not found"})
            continue

        for yml in yamls:
            try:
                proc = load_process_yaml(yml)
                Qdot, Hin, Hout, details = Q_blackbox_kW(proc, idx)

                proc_name = proc.get("process", yml.parent.name)
                # Create a safe filename
                safe = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in proc_name)[:80]
                out_file = out_root / f"{sf}__{safe}.json"

                payload = {
                    "process": proc_name,
                    "process_folder": sf,
                    "source_yaml": str(yml),
                    "connector_database": str(db_path),
                    "calculated_at_utc": timestamp,
                    "convention": {
                        "Qdot_kW": "Qdot = sum(mdot*h)_out - sum(mdot*h)_in",
                        "sign": "positive = net heat into black box",
                    },
                    "results": {
                        "Hin_kW": Hin,
                        "Hout_kW": Hout,
                        "Qdot_kW": Qdot,
                    },
                    "streams": details,
                }

                write_json(out_file, payload)

                summary_rows.append({
                    "process_folder": sf,
                    "process": proc_name,
                    "Qdot_kW": Qdot,
                    "Hin_kW": Hin,
                    "Hout_kW": Hout,
                    "result_json": str(out_file),
                    "source_yaml": str(yml),
                })

            except Exception as e:
                failures.append({
                    "folder": sf,
                    "yaml": str(yml),
                    "error": str(e),
                })

    # Write summary json
    summary = {
        "calculated_at_utc": timestamp,
        "connector_database": str(db_path),
        "process_root": str(process_root),
        "results_root": str(out_root),
        "n_success": len(summary_rows),
        "n_fail": len(failures),
        "summary": summary_rows,
        "failures": failures,
    }

    write_json(out_root / "process_results_summary.json", summary)

    # Optional: also print a short console summary (useful in Quarto logs)
    print(f"Saved: {out_root / 'process_results_summary.json'}")
    print(f"Success: {len(summary_rows)} | Failures: {len(failures)}")


if __name__ == "__main__":
    main()