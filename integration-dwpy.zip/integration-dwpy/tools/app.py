# pip install pywin32 pythonnet pyyaml pandas streamlit matplotlib
# python -m streamlit run "Z:\dwsim-python\integration-dwpy\tools\app.py"

# integration_path represents the full path to the file, while integration_path.parent returns the path of the immediate directory above it.

from __future__ import annotations

import datetime as dt
import importlib.util
import json
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd
import streamlit as st
import yaml

from paths import get_connectors_root


# ----------------------------
# Data Model: Connector Case (This block defines the official structure that represents a connector case within the system.)
# ----------------------------

# CaseRef is an immutable data structure representing a single connector case discovered in the project folders.

# It stores:
# - connector: name of the connector folder (e.g., "water")
# - case: name of the case folder (e.g., "p1")
# - catalog_path: path to catalog.yaml
# - integration_path: path to integration.py

# The @dataclass decorator automatically generates the constructor and other utility methods, avoiding manual boilerplate code.

@dataclass(frozen=True)
class CaseRef:
    connector: str
    case: str
    catalog_path: Path
    integration_path: Path

# ----------------------------
# Discovery
# ----------------------------

# The Discovery block is responsible for automatically identifying all valid cases inside the connectors/<group>/ directory and preparing them for execution.

def discover_cases(connectors_root: Path, group: str = "pinch") -> List[CaseRef]: # This line defines a function called discover_cases that requires a path, and when executed will return a list of CaseRef objects  (at this point it is only being defined and not yet executed). 
    base = connectors_root / group
    if not base.exists():
        return []
    
# Explanation line 49/51:
    # Builds the path connectors_root/group, checks whether that path exists, returns an empty list if it does not exist, and continues executing the function if it does.
    # Example
        # connectors_root = Z:\dwsim-python\integration-dwpy\connectors
        # group = "pinch"
            # Therefore, base = Z:\dwsim-python\integration-dwpy\connectors\pinch

    cases: List[CaseRef] = [] # Create an empty list called cases. This list is intended to store CaseRef objects.
    for catalog in base.rglob("catalog.yaml"): # search inside 'base' for every file named "catalog.yaml"
        # catalog = It is the full path to the file, therefore, for example "catalog = base\connector\case\catalog.yaml"

        case_dir = catalog.parent
        # 'catalog.parent' means the folder that contains this file (case folder).
        #  then case_dir = base\connector\case (path to the folder)

        connector_dir = case_dir.parent
         # If: case_dir = "base\connector\case", Then: connector_dir = "base/connector". This folder represents the connector (for example, "water").

    #connectors/
    #└── pinch/
        #└── connector/
            #├── case1/
                 # └── catalog.yaml
            #└── #case2/
                  # └── catalog.yaml

        connector = connector_dir.name # connector_dir.name → "connector"
        case = case_dir.name # connector_dir.name → "case"
        integration = case_dir / "integration.py" # this builds the final path to integration.py: base\connector\case\integration.py

        if not integration.exists():
            continue
            # This means:
                # If integration.py does NOT exist, ignore this case and continue the loop (move to the next catalog.yaml).
                # ⚠️ This is important: A case is only valid if it contains a catalog.yaml AND a integration.py. Without integration.py, the case is not executable.

        cases.append( # cases = [CaseRef(...), CaseRef(...)]
            CaseRef( # defined in: Data model definition for a connector case (Line 40/44).
                connector=connector,
                case=case,
                catalog_path=catalog, # catalog =  path to catalog.yaml: "catalog = base\connector\case\catalog.yaml"
                integration_path=integration, # integration =  path to integration.py: "integration = base\connector\case\integration.py"
            )
        )

    cases.sort(key=lambda x: (x.connector.lower(), x.case.lower()))
    return cases

    # Therefore, cases is something like:
        # cases = [CaseRef(...connector/case...), CaseRef(...connector/case...), CaseRef(...connector/case/...)]

def load_integration_module(integration_path: Path): # The function receives the path to integration.py (e.g., Z:\...\integration.py).
    
    unique_name = (
        f"integration__{integration_path.parent.name}__"
        f"{abs(hash(str(integration_path))) % 10_000_000}"
    )

# From lines 107/110: Create a unique module name:
    # A unique name is generated from the case folder (integration_path.parent.name) and full file path (integration_path)
    # This is made to prevent conflicts when multiple integration.py files are loaded.
    
    spec = importlib.util.spec_from_file_location(unique_name, str(integration_path)) # Create a ModuleSpec object, which  defines the internal module name (unique_name), the file location on disk (integration_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec: {integration_path}")
    
# From lines 119 to 121:
    # Verify that the module specification was created successfully.
    # If the path is invalid, the file is inaccessible, or the loader failed,
    # raise an error immediately to prevent loading a misconfigured module.

    mod = importlib.util.module_from_spec(spec) # Create an empty module object in memory based on the module specification.
    spec.loader.exec_module(mod) # Main step: the loader opens integration.py, reads and compiles the code, executes it, and populates the module object (mod) with its definitions.
    return mod  # Return the fully loaded and executed module so it can be used elsewhere in the program.

    # Lines 128 to 130: Create an empty module, execute integration.py inside it, and return the loaded module so its functions can be used by the system.

def get_generic_engine_path(connectors_root: Path) -> Path: # Define a function that receives the path to the connectors directory, and returns a Path object.
    p = (connectors_root / "generic" / "integration.py").resolve() 

# p = Build the full path to connectors/generic/integration.py 
    # if connectors_root =Z:\dwsim-python\integration-dwpy\connectors
    # then, p = Z:\dwsim-python\integration-dwpy\connectors\generic\integration.py
# .resolve() = converts it into a normalized absolute path.

    if not p.exists(): # Check whether the file exists on disk.
        raise FileNotFoundError(f"Generic engine not found: {p}") # If it does not exist, raise a clear error immediately.
    return p # If it exists, return the validated path.

# This function does NOT load the module — it only provides the correct path.

# Therefore, build and validate the path to the system's generic engine (Q calculation), ensuring that connectors/generic/integration.py exists.

# ----------------------------
# Helpers
# ----------------------------

# Purpose of this function  (lines 156 to 170): Safely format a value for display.
    # If possible, convert it to float and format it with a fixed number of decimal places; otherwise, return a readable fallback string.

def _fmt(x: Any, nd: int = 3) -> str: # Helper function

# This helper function:
    # - Receives a value x (of any type → Any)
    # - Optionally receives nd (number of decimal places), default = 3
    # - Returns a string (-> str)
    # The leading "_" indicates that this is an internal/private helper function.

    if x is None:
        return "—" # If x is none, return —
    try:
        return f"{float(x):.{nd}f}" # Attempt to convert x to a float and format it using nd decimal places.
    except Exception:
        return str(x)
        # If conversion to float fails (e.g., x is text), return it as a string.

# Purpose of the function (lines 175 to 187): Attempt to extract the specific enthalpy value (h_kJ_kg) from a result object (res) and return it as a float.
# what the function wants to do: res["properties"]["h_kJ_kg"] (res for result)

def _extract_h_kjkg(res: Any) -> Optional[float]:   
    # Define a helper function that attempts to extract the specific enthalpy value (h_kJ_kg) from a result object and return it as a float.
    if not isinstance(res, dict): # res must be a dictionary (e.g., {"properties": {...}}), because we later access nested keys such as res["properties"]["h_kJ_kg"].
        return None # If the result is not a dictionary, extraction is not possible.
    props = res.get("properties") or {} # This attempts to retrieve the value associated with the key "properties" from the dictionary res
    h = props.get("h_kJ_kg", None) # it returns None if the key does not exist.
    try:
        return float(h) if h is not None else None # Attempt to convert h to a float. If conversion is not possible, return None.
    except Exception:
        return None
    # Example: 
        # float(2500.5)      → 2500.5
        # float("abc")       → ERRO

# Purpose of the function (lines 194 to 200): Attempt to extract the default mass flow value (massflow_kg_s) from the catalog configuration (cfg) and return it as a float.
    # If extraction or conversion fails, return None.

def _default_massflow_from_catalog(cfg: Dict[str, Any]) -> Optional[float]:
    rf = cfg.get("reference_flow") or {}
    m = rf.get("massflow_kg_s", None)
    try:
        return float(m) if m is not None else None
    except Exception:
        return None
    
# Note on naming:
# _extract_h_kjkg reads (extracts) a value that was already computed in a simulation result dictionary (res). It retrieves an output value produced by the connector execution.
# _default_massflow_from_catalog reads a predefined configuration value from the catalog dictionary (cfg). It retrieves an initial/default reference value, not a computed result.

    # Although both functions have similar logic (safe dictionary access and loat conversion), they operate on different data sources and represent different stages in the workflow: 
        # one extracts a calculated result,
        # the other retrieves a default configuration parameter.

# Purpose of the function (lines 216 to 227): The name apply_overrides means: Apply parameter overrides to a configuration.
# In other words, starting from a base configuration dictionary (cfg), selectively replace specific parameters such as:
    # - Temperature (T_C)
    # - Pressure (P_bar)
    # - Mass flow rate (m_kg_s)
    # - Property package (ppkg)
        # without modifying the chemical composition.

def apply_overrides(
    cfg: Dict[str, Any],
    T_C: float,
    P_bar: float,
    m_kg_s: Optional[float],
    ppkg: Optional[str],
) -> Dict[str, Any]:
    """
    DOES NOT change composition (compounds).
    Only overrides T, P, massflow, property_package.
    """
    cfg2 = dict(cfg) # Create a shallow copy of cfg to avoid modifying the original dictionary in memory.

    cfg2.setdefault("state", {})
    # Ensure the key "state" exists in cfg2.
    # If it does not exist, create it with an empty dictionary as default.

    cfg2["state"] = dict(cfg2["state"])
    # Create a shallow copy of the "state" dictionary to avoid modifying the original nested structure.

    cfg2["state"]["T_C"] = float(T_C)
    # Override the temperature (T_C) in the "state" section, ensuring it is stored as a float.

    cfg2["state"]["P_bar"] = float(P_bar)
    # Override the pressure (P_bar) in the "state" section, ensuring it is stored as a float.

    if m_kg_s is not None:
    # Only override the mass flow if a new value was provided.
    # If m_kg_s is None, keep the original catalog value.
        cfg2.setdefault("reference_flow", {})
        # Ensure that the "reference_flow" section exists.
        # If it does not exist, create it as an empty dictionary
        cfg2["reference_flow"] = dict(cfg2["reference_flow"])
        # Create a shallow copy of the "reference_flow" dictionary to avoid modifying the original nested structure.
        cfg2["reference_flow"]["massflow_kg_s"] = float(m_kg_s)
        # Override the mass flow value (massflow_kg_s), ensuring it is stored as a float.

    if ppkg:
    # Only override the property package if a new value was provided.
    # If ppkg is None or empty, keep the original value.
        cfg2.setdefault("model", {})
        # Ensure that the "model" section exists in the configuration.
        # If it does not exist, create it as an empty dictionary.
        cfg2["model"] = dict(cfg2["model"])
         # Create a shallow copy of the "model" dictionary to avoid modifying the original nested structure.
        cfg2["model"]["property_package"] = str(ppkg)
        # Override the "property_package" field, ensuring the value is stored as a string

    return cfg2
    # Return the updated configuration dictionary with all applied overrides.

def write_temp_catalog(
    connectors_root: Path,
    namespace: str,
    name: str,
    cfg: Dict[str, Any],
) -> Path:
    """
    Writes:
      connectors/_tmp_runs/<namespace>/<name>/<timestamp>/catalog.yaml
    """
    ts = time.strftime("%Y%m%d-%H%M%S")
    # sanitize to avoid accidental folder separators
    safe = name.replace("\\", "_").replace("/", "_").replace(":", "_")
    tmp_dir = connectors_root / "_tmp_runs" / namespace / safe / ts
    tmp_dir.mkdir(parents=True, exist_ok=True)

    tmp_catalog = tmp_dir / "catalog.yaml"
    tmp_catalog.write_text(
        yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
    return tmp_catalog


def build_connector_default_catalog_map(cases: List[CaseRef]) -> Dict[str, CaseRef]:
    """
    For each connector, pick a default CaseRef ONLY to read composition + defaults.
    Strategy: alphabetical first case (stable).
    """
    by_conn: Dict[str, List[CaseRef]] = {}
    for c in cases:
        by_conn.setdefault(c.connector, []).append(c)

    out: Dict[str, CaseRef] = {}
    for conn, lst in by_conn.items():
        lst_sorted = sorted(lst, key=lambda x: x.case.lower())
        out[conn] = lst_sorted[0]
    return out


def build_connector_cases_map(cases: List[CaseRef]) -> Dict[str, List[CaseRef]]:
    """
    Groups all CaseRef objects by connector name.
    This is used in Single connector so the user can pick BOTH:
    - Connector
    - Case (within that connector)
    """
    by_conn: Dict[str, List[CaseRef]] = {}
    for c in cases:
        by_conn.setdefault(c.connector, []).append(c)

    # keep stable ordering for UI
    for conn in list(by_conn.keys()):
        by_conn[conn] = sorted(by_conn[conn], key=lambda x: x.case.lower())
    return by_conn


def make_auto_uid(rows: List[Dict[str, Any]], connector_name: str) -> str:
    base = connector_name.strip() or "Stream"
    count = sum(1 for r in rows if str(r.get("connector", "")).strip() == base) + 1
    return f"{base}_{count}"

# ----------------------------
# Saving JSON in connectors/generic/json/ with clean names
# ----------------------------
def _unique_name_path(folder: Path, base_name: str) -> Path:
    """
    Returns:
      base.json
      base (1).json
      base (2).json
    """
    base = (base_name or "test").strip()
    base = base.replace("/", "-").replace("\\", "-").strip()
    if not base:
        base = "test"

    p0 = folder / f"{base}.json"
    if not p0.exists():
        return p0

    i = 1
    while True:
        pi = folder / f"{base} ({i}).json"
        if not pi.exists():
            return pi
        i += 1


def save_test_json(connectors_root: Path, payload: Dict[str, Any], test_name: str) -> Path:
    out_dir = (connectors_root / "generic" / "json").resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    out_path = _unique_name_path(out_dir, test_name)
    out_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out_path


# ----------------------------
# Session state (Scenario Builder)
# ----------------------------
def _init_builder_state() -> None:
    if "processes" not in st.session_state:
        st.session_state["processes"] = {}  # process_name -> list[dict]
    if "active_process" not in st.session_state:
        st.session_state["active_process"] = ""
    if "process_name_input" not in st.session_state:
        st.session_state["process_name_input"] = ""


def _get_active_rows() -> List[Dict[str, Any]]:
    name = st.session_state.get("active_process", "")
    if not name:
        return []
    return st.session_state["processes"].setdefault(name, [])


# ----------------------------
# UI: Single connector (connector + case + generic engine)
# ----------------------------
def ui_single_connector(
    cases: List[CaseRef],
    connectors_root: Path,
    generic_engine_path: Path,
) -> None:
    st.subheader("Single connector")

    # We want: user chooses Connector, then chooses Case (only for Single connector)
    by_conn = build_connector_cases_map(cases)
    connectors = sorted(by_conn.keys(), key=str.lower)

    picked_connector = st.selectbox("Connector", connectors, key="single_connector_only")

    case_refs = by_conn.get(picked_connector, [])
    if not case_refs:
        st.warning("No cases found for this connector.")
        return

    case_names = [c.case for c in case_refs]
    picked_case = st.selectbox("Case", case_names, key="single_case_only")

    # Find the CaseRef for the selected case
    base_ref = next((c for c in case_refs if c.case == picked_case), case_refs[0])

    # Load YAML for THIS case (so defaults change when case changes)
    template_cfg = yaml.safe_load(base_ref.catalog_path.read_text(encoding="utf-8")) or {}

    # Default values coming from THIS case YAML
    default_T_C = float((template_cfg.get("state") or {}).get("T_C", 25.0))
    default_P_bar = float((template_cfg.get("state") or {}).get("P_bar", 1.0))
    default_m = _default_massflow_from_catalog(template_cfg)
    default_pp = str((template_cfg.get("model") or {}).get("property_package", "PengRobinson"))

    # ----------------------------
    # IMPORTANT UX:
    # When user changes the case, we want to reset inputs to the YAML defaults.
    #
    # Streamlit keeps widget values by "key", so we must update session_state BEFORE creating widgets.
    # We do it like this:
    # 1) detect a new (connector, case) selection
    # 2) set session_state for widgets to the YAML defaults
    # 3) rerun, so widgets are created cleanly from session_state
    #
    # This avoids the Streamlit warning and guarantees T/P/ṁ update when case changes.
    # ----------------------------
    selected_id = f"{picked_connector}::{picked_case}"
    last_id = st.session_state.get("_single_last_case_id")
    if last_id != selected_id:
        st.session_state["_single_last_case_id"] = selected_id

        # Reset widgets to YAML defaults
        st.session_state["single_T"] = default_T_C
        st.session_state["single_P"] = default_P_bar
        st.session_state["single_pp"] = default_pp

        # Massflow: ALWAYS show, so store a value from YAML
        st.session_state["single_m"] = float(default_m) if default_m is not None else 1.0

        # Override checkbox: default = False (use YAML massflow)
        st.session_state["single_override_m"] = False

        st.rerun()

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        # Widget value comes from session_state["single_T"]
        T_C = st.number_input("T (°C)", step=1.0, key="single_T")

    with col2:
        # Widget value comes from session_state["single_P"]
        P_bar = st.number_input("P (bar)", step=0.1, key="single_P")

    with col3:
        # Massflow ALWAYS visible
        mdot_user = st.number_input("ṁ (kg/s)", step=0.1, key="single_m")
        use_override = st.checkbox("Override massflow", key="single_override_m")
        m_kg_s = float(mdot_user) if use_override else None

    with col4:
        # Widget value comes from session_state["single_pp"]
        ppkg = st.text_input("Property package", key="single_pp")

    cfg_run = apply_overrides(template_cfg, T_C=T_C, P_bar=P_bar, m_kg_s=m_kg_s, ppkg=ppkg)

    if not st.button("Run (compute properties)", key="single_run"):
        return

    try:
        engine_mod = load_integration_module(generic_engine_path)
        run_connector = getattr(engine_mod, "run_connector", None)
        if run_connector is None:
            st.error("Generic engine does not expose run_connector(catalog_yaml_path: str).")
            return

        # Use connector+case in the temp folder name (keeps things organized)
        tmp_catalog = write_temp_catalog(
            connectors_root,
            "single",
            f"{picked_connector}__{picked_case}",
            cfg_run,
        )

        res = run_connector(str(tmp_catalog))
        if isinstance(res, dict):
            props = res.get("properties") or {}
            state = res.get("state") or {}

            st.subheader("Key properties")
            cA, cB, cC = st.columns(3)
            cD, cE, cF = st.columns(3)

            cA.metric("T (K)", _fmt(state.get("T_K"), 2))
            cB.metric("P (Pa)", _fmt(state.get("P_Pa"), 0))
            cC.metric("Phase", str(props.get("phase") or "—"))

            cD.metric("h (kJ/kg)", _fmt(props.get("h_kJ_kg"), 3))
            cE.metric("s (kJ/kg·K)", _fmt(props.get("s_kJ_kgK"), 3))
            cF.metric("Vapor fraction", _fmt(props.get("vapor_fraction"), 6))

    except Exception:
        st.error("Run failed. Traceback:")
        st.code(traceback.format_exc())


# ----------------------------
# UI: Scenario Builder (clean UI + save json with clean names)
# ----------------------------
def ui_scenario_builder(
    cases: List[CaseRef],
    connectors_root: Path,
    generic_engine_path: Path,
) -> None:
    st.subheader("Scenario Builder")
    _init_builder_state()

    # Process name + create
    c1, c2 = st.columns([3, 1])
    with c1:
        process_name = st.text_input(
            "Process name",
            value=st.session_state["process_name_input"],
            placeholder="p1",
        )
        st.session_state["process_name_input"] = process_name
    with c2:
        if st.button("Create", type="primary", use_container_width=True):
            name = (process_name or "").strip()
            if not name:
                st.warning("Please enter a process name.")
            else:
                st.session_state["processes"][name] = []
                st.session_state["active_process"] = name
                st.rerun()

    active = st.session_state.get("active_process", "")
    if not active:
        st.info("Create a process to start adding streams.")
        return

    rows = _get_active_rows()

    default_map = build_connector_default_catalog_map(cases)
    connectors = sorted(default_map.keys(), key=str.lower)

    # Add stream controls
    sel1, sel2 = st.columns([4, 1])
    with sel1:
        picked_connector = st.selectbox("Connector", connectors, key="sb_pick_connector")
    with sel2:
        direction = st.selectbox("Dir", ["in", "out"], key="sb_pick_dir")

    base_ref = default_map[picked_connector]
    template_cfg = yaml.safe_load(base_ref.catalog_path.read_text(encoding="utf-8")) or {}

    default_T_C = float((template_cfg.get("state") or {}).get("T_C", 25.0))
    default_P_bar = float((template_cfg.get("state") or {}).get("P_bar", 1.01325))
    default_m = _default_massflow_from_catalog(template_cfg)
    default_m = float(default_m) if default_m is not None else 1.0
    default_pp = str((template_cfg.get("model") or {}).get("property_package", "PengRobinson"))

    o1, o2, o3, o4, o5 = st.columns([1, 1, 1, 2, 1])
    with o1:
        T_C = st.number_input("T (°C)", value=default_T_C, step=1.0, key="sb_T")
    with o2:
        P_bar = st.number_input("P (bar)", value=default_P_bar, step=0.1, key="sb_P")
    with o3:
        mdot = st.number_input("ṁ (kg/s)", value=default_m, step=0.1, key="sb_m")
    with o4:
        ppkg = st.text_input("Property package", value=default_pp, key="sb_pp")
    with o5:
        if st.button("Add stream", use_container_width=True):
            uid2 = make_auto_uid(rows, picked_connector)
            rows.append(
                {
                    "delete": False,
                    "uid": uid2,
                    "connector": picked_connector,
                    "direction": direction,
                    "T_C": float(T_C),
                    "P_bar": float(P_bar),
                    "mdot_kg_s": float(mdot),
                    "property_package": str(ppkg).strip() or default_pp,
                    "base_catalog": str(base_ref.catalog_path),  # internal only
                }
            )
            st.session_state["processes"][active] = rows
            st.rerun()

    with st.expander("Fixed composition (read-only)", expanded=False):
        st.json(template_cfg.get("compounds") or {})

    # Editable table (hide base_catalog)
    st.write("### Streams (editable)")
    if rows:
        df_full = pd.DataFrame(rows)
    else:
        df_full = pd.DataFrame(
            columns=[
                "delete",
                "uid",
                "connector",
                "direction",
                "T_C",
                "P_bar",
                "mdot_kg_s",
                "property_package",
                "base_catalog",
            ]
        )

    df_display = df_full.drop(columns=["base_catalog"], errors="ignore")

    edited = st.data_editor(
        df_display,
        use_container_width=True,
        num_rows="dynamic",
        column_config={
            "delete": st.column_config.CheckboxColumn("delete", help="Mark to remove"),
            "direction": st.column_config.SelectboxColumn("direction", options=["in", "out"], required=True),
            "T_C": st.column_config.NumberColumn("T_C", format="%.3f"),
            "P_bar": st.column_config.NumberColumn("P_bar", format="%.6f"),
            "mdot_kg_s": st.column_config.NumberColumn("mdot_kg_s", format="%.8f"),
            "property_package": st.column_config.TextColumn("property_package"),
            "uid": st.column_config.TextColumn("uid"),
            "connector": st.column_config.TextColumn("connector"),
        },
        key="sb_table",
    )

    # Re-attach base_catalog by uid
    uid_to_base = {str(r.get("uid")): str(r.get("base_catalog")) for r in rows if r.get("uid")}
    merged_rows: List[Dict[str, Any]] = []
    for r in edited.to_dict(orient="records"):
        u = str(r.get("uid", "")).strip()
        r2 = dict(r)
        r2["base_catalog"] = uid_to_base.get(u, "")
        merged_rows.append(r2)

    st.session_state["processes"][active] = merged_rows
    rows = merged_rows

    # Only one remove button
    rm1, rm2 = st.columns([2, 8])
    with rm1:
        if st.button("Remove stream(s)", type="secondary", use_container_width=True):
            cleaned = [r for r in rows if not bool(r.get("delete", False))]
            for r in cleaned:
                r["delete"] = False
            st.session_state["processes"][active] = cleaned
            st.rerun()
    with rm2:
        st.write("")

    st.divider()

    # Only two buttons: Run + Reset
    b1, b2 = st.columns([2, 2])
    with b1:
        run_btn = st.button("Run process (compute h + Q̇)", type="primary", use_container_width=True)
    with b2:
        if st.button("Reset process (clear streams)", type="secondary", use_container_width=True):
            st.session_state["processes"][active] = []
            st.rerun()

    if not run_btn:
        return

    if not rows:
        st.warning("Add at least one stream.")
        return

    # Load generic engine
    try:
        engine_mod = load_integration_module(generic_engine_path)
        run_connector = getattr(engine_mod, "run_connector", None)
        if run_connector is None:
            st.error("Generic engine does not expose run_connector(catalog_yaml_path: str).")
            return
    except Exception:
        st.error("Failed to load generic engine. Traceback:")
        st.code(traceback.format_exc())
        return

    st.info("Running DWSIM for each stream…")
    results_rows: List[Dict[str, Any]] = []
    errors: List[str] = []
    prog = st.progress(0.0)

    for i, srow in enumerate(rows, start=1):
        uid2 = str(srow.get("uid", f"stream_{i}")).strip() or f"stream_{i}"
        conn = str(srow.get("connector", "")).strip()
        direction2 = str(srow.get("direction", "in")).lower().strip()

        try:
            base_catalog_path = Path(str(srow.get("base_catalog", ""))).resolve()
            if not base_catalog_path.exists():
                raise FileNotFoundError(f"Base catalog not found for {uid2}")

            template_cfg2 = yaml.safe_load(base_catalog_path.read_text(encoding="utf-8")) or {}

            T_C2 = float(srow.get("T_C"))
            P_bar2 = float(srow.get("P_bar"))
            mdot2 = float(srow.get("mdot_kg_s"))
            ppkg2 = str(srow.get("property_package") or "").strip() or None

            cfg_run = apply_overrides(template_cfg2, T_C=T_C2, P_bar=P_bar2, m_kg_s=mdot2, ppkg=ppkg2)

            tmp_catalog = write_temp_catalog(connectors_root, "scenario", f"{active}__{uid2}", cfg_run)
            res = run_connector(str(tmp_catalog))

            h_kJ_kg = _extract_h_kjkg(res)
            if h_kJ_kg is None:
                raise ValueError("Could not extract h_kJ_kg from connector result.")

            Hdot_kW = mdot2 * h_kJ_kg  # (kg/s)*(kJ/kg)=kW

            results_rows.append(
                {
                    "uid": uid2,
                    "connector": conn,
                    "direction": direction2,
                    "T_C": T_C2,
                    "P_bar": P_bar2,
                    "mdot_kg_s": mdot2,
                    "property_package": ppkg2 or "",
                    "h_kJ_kg": h_kJ_kg,
                    "Hdot_kW": Hdot_kW,
                    "raw_result": res,
                }
            )

        except Exception as e:
            errors.append(f"{uid2} ({conn}): {type(e).__name__}: {e}")

        finally:
            prog.progress(i / len(rows))

    if errors:
        st.error("Some streams failed:")
        for e in errors:
            st.write("- ", e)

    if not results_rows:
        st.stop()

    df_res = pd.DataFrame(results_rows)
    df_res["direction"] = df_res["direction"].str.lower().str.strip()

    Hin = float(df_res.loc[df_res["direction"] == "in", "Hdot_kW"].sum())
    Hout = float(df_res.loc[df_res["direction"] == "out", "Hdot_kW"].sum())
    Qdot = Hout - Hin

    st.success("Process finished.")
    m1, m2, m3 = st.columns(3)
    m1.metric("Σ Ḣ_in (kW)", _fmt(Hin, 3))
    m2.metric("Σ Ḣ_out (kW)", _fmt(Hout, 3))
    m3.metric("Q̇ = Ḣ_out − Ḣ_in (kW)", _fmt(Qdot, 3))

    st.write("### Stream results")
    show_cols = ["uid", "connector", "direction", "T_C", "P_bar", "mdot_kg_s", "property_package", "h_kJ_kg", "Hdot_kW"]
    st.dataframe(df_res[show_cols], use_container_width=True)

    payload = {
        "calculated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "test": active,
        "convention": {
            "Qdot_kW": "Qdot = sum(mdot*h)_out - sum(mdot*h)_in",
            "sign": "positive = net heat into black box",
        },
        "results": {"Hin_kW": Hin, "Hout_kW": Hout, "Qdot_kW": Qdot},
        "streams": results_rows,
    }

    # Save silently (no UI prints), clean filenames: p1.json / p1 (1).json / ...
    save_test_json(connectors_root, payload, test_name=active)


# ----------------------------
# Page layout
# ----------------------------
st.set_page_config(page_title="DWSIM-python", layout="wide")
st.title("DWSIM-python")

# We resolve the connectors root using a shared, portable helper (paths.py).
connectors_root = get_connectors_root(start=Path(__file__))

cases = discover_cases(connectors_root, group="pinch")
if not cases:
    st.error("No cases found under connectors/pinch/**/catalog.yaml with an integration.py next to it.")
    st.stop()

try:
    generic_engine_path = get_generic_engine_path(connectors_root)
except Exception:
    st.error("Generic engine not found or invalid. Traceback:")
    st.code(traceback.format_exc())
    st.stop()

tab1, tab2 = st.tabs(["Single connector", "Scenario Builder"])
with tab1:
    ui_single_connector(cases, connectors_root, generic_engine_path)
with tab2:
    ui_scenario_builder(cases, connectors_root, generic_engine_path)