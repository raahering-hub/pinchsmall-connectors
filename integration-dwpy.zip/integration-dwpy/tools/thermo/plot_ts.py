from __future__ import annotations

import os
import csv
import glob
from typing import List, Optional, Tuple

import numpy as np
import matplotlib.pyplot as plt


def load_rows_from_csv(csv_path: str) -> List[dict]:
    rows: List[dict] = []
    with open(csv_path, "r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append({
                "T_C": float(row["T_C"]),
                "P_bar": float(row["P_bar"]),
                "h_kJ_kg": float(row["h_kJ_kg"]),
                "s_kJ_kgK": float(row["s_kJ_kgK"]),
                "x": float(row["x"]),
                "phase": str(row.get("phase", "")),
            })
    return rows


def _group_by_pressure(rows: List[dict]) -> dict[float, List[dict]]:
    out: dict[float, List[dict]] = {}
    for r in rows:
        out.setdefault(float(r["P_bar"]), []).append(r)
    return out


def _snap_to_available_log(value: float, available: List[float]) -> float:
    av = np.array(available, dtype=float)
    return float(av[np.argmin(np.abs(np.log(av) - np.log(float(value))))])


def _format_pressure_label(P_bar: float) -> str:
    if P_bar >= 1:
        return f"{P_bar:g} bar"
    return f"{P_bar:.2f}".rstrip("0").rstrip(".") + " bar"


def _format_mpa(v: float) -> str:
    if v >= 1:
        return f"{v:g}"
    if v >= 0.1:
        return f"{v:.1f}".rstrip("0").rstrip(".")
    return f"{v:.2f}".rstrip("0").rstrip(".")


def _interp_and_smooth_branch(
    line: List[dict],
    n: int = 1400,
    window: int = 51,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Interpolate s(T) on a dense T grid and smooth slightly.
    Used to remove the staircase look from vapor-branch pressure lines.
    """
    if len(line) < 2:
        return np.array([]), np.array([])

    line = sorted(line, key=lambda rr: rr["T_C"])
    T = np.array([rr["T_C"] for rr in line], dtype=float)
    s = np.array([rr["s_kJ_kgK"] for rr in line], dtype=float)

    T_u, idx = np.unique(T, return_index=True)
    s_u = s[idx]

    if len(T_u) < 2:
        return np.array([]), np.array([])

    T_f = np.linspace(float(T_u.min()), float(T_u.max()), int(n))
    s_f = np.interp(T_f, T_u, s_u)

    # moving-average smoothing
    w = max(5, int(window))
    if w % 2 == 0:
        w += 1

    if len(s_f) > w:
        kernel = np.ones(w, dtype=float) / w
        pad = w // 2
        s_pad = np.pad(s_f, (pad, pad), mode="edge")
        s_f = np.convolve(s_pad, kernel, mode="valid")

    return s_f, T_f


def build_sat_tables(rows: List[dict]) -> tuple[list[dict], list[dict], dict[float, dict], dict[float, dict]]:
    sat = [r for r in rows if r.get("phase") == "sat_line"]

    sat_liq = sorted(
        [r for r in sat if abs(float(r["x"]) - 0.0) < 1e-12],
        key=lambda rr: rr["P_bar"]
    )
    sat_vap = sorted(
        [r for r in sat if abs(float(r["x"]) - 1.0) < 1e-12],
        key=lambda rr: rr["P_bar"]
    )

    byP_liq = {float(r["P_bar"]): r for r in sat_liq}
    byP_vap = {float(r["P_bar"]): r for r in sat_vap}

    return sat_liq, sat_vap, byP_liq, byP_vap


def _place_label_on_vapor_branch(
    ax,
    s_curve: np.ndarray,
    T_curve: np.ndarray,
    label: str,
    T_label: float,
    dx: float = 0.05,
    dy: float = 0.0,
    fontsize: int = 9,
):
    """
    Place pressure label on the right-side vapor branch at a chosen temperature.
    """
    if len(s_curve) < 5:
        return

    idx = int(np.argmin(np.abs(T_curve - T_label)))
    x = float(s_curve[idx]) + dx
    y = float(T_curve[idx]) + dy

    ax.text(
        x,
        y,
        label,
        fontsize=fontsize,
        ha="left",
        va="center",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.60, pad=0.5)
    )


def plot_ts_readable(
    csv_path: str,
    png_path: Optional[str] = None,
    title: Optional[str] = None,
    figsize: Tuple[float, float] = (18, 10),
    dpi: int = 300,
    xlim: Tuple[float, float] = (0.0, 9.0),
    ylim: Tuple[float, float] = (0.0, 400.0),
):
    rows = load_rows_from_csv(csv_path)

    sat = [r for r in rows if r.get("phase") == "sat_line"]
    scan = [r for r in rows if r.get("phase") != "sat_line"]

    fig = plt.figure(figsize=figsize, dpi=dpi)
    ax = plt.gca()

    sat_liq, sat_vap, byP_liq, byP_vap = build_sat_tables(rows)

    # ------------------------------------------------------------
    # 1) Dome
    # ------------------------------------------------------------
    if len(sat_liq) > 5:
        ax.plot(
            [r["s_kJ_kgK"] for r in sat_liq],
            [r["T_C"] for r in sat_liq],
            linewidth=2.8
        )

    if len(sat_vap) > 5:
        ax.plot(
            [r["s_kJ_kgK"] for r in sat_vap],
            [r["T_C"] for r in sat_vap],
            linewidth=2.8
        )

    # ------------------------------------------------------------
    # 2) Quality lines
    # ------------------------------------------------------------
    for xq in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
        pts = [r for r in sat if abs(float(r["x"]) - xq) < 1e-12]
        pts = sorted(pts, key=lambda rr: rr["P_bar"])
        if len(pts) < 5:
            continue

        ax.plot(
            [p["s_kJ_kgK"] for p in pts],
            [p["T_C"] for p in pts],
            linestyle="--",
            linewidth=0.8,
            alpha=0.65
        )

    for xq in [0.1, 0.5, 0.9]:
        pts = [r for r in sat if abs(float(r["x"]) - xq) < 1e-12]
        pts = sorted(pts, key=lambda rr: rr["P_bar"])
        if len(pts) > 6:
            j = int(0.58 * (len(pts) - 1))
            ax.text(pts[j]["s_kJ_kgK"], pts[j]["T_C"], f"x={xq:.1f}", fontsize=9)

    # ------------------------------------------------------------
    # 3) Pressure labels on RIGHT only:
    #    draw ONLY smooth vapor branches of main pressures
    # ------------------------------------------------------------
    scan_by_P = _group_by_pressure(scan)
    all_P = sorted(scan_by_P.keys())

    p_show_bar = [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100]

    pressure_label_temperature_map = {
        100: 330,
        50: 290,
        20: 255,
        10: 190,
        5: 160,
        2: 135,
        1: 115,
        0.5: 95,
        0.2: 80,
        0.1: 70,
    }

    for P_target in p_show_bar:
        if not all_P:
            break

        P_bar = _snap_to_available_log(float(P_target), all_P)
        line = sorted(scan_by_P[P_bar], key=lambda rr: rr["T_C"])

        Tsat = byP_liq[P_bar]["T_C"] if P_bar in byP_liq else None
        if Tsat is None:
            continue

        # vapor branch only
        vapor = [r for r in line if r["T_C"] > Tsat + 0.2]
        sV, TV = _interp_and_smooth_branch(vapor, n=1400, window=51)

        if len(sV) > 5:
            ax.plot(sV, TV, linewidth=1.0, alpha=0.80)

            label = _format_pressure_label(P_bar)
            T_label = pressure_label_temperature_map.get(P_target, 120)
            _place_label_on_vapor_branch(
                ax,
                sV,
                TV,
                label,
                T_label=T_label,
                dx=0.05,
                dy=0.0,
                fontsize=9
            )

    # ------------------------------------------------------------
    # 4) Isoenthalpies
    # ------------------------------------------------------------
    T_scan = np.array([r["T_C"] for r in scan], dtype=float)
    s_scan = np.array([r["s_kJ_kgK"] for r in scan], dtype=float)
    h_scan = np.array([r["h_kJ_kg"] for r in scan], dtype=float)

    h_levels = [200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2400, 2600]

    try:
        cs_h = ax.tricontour(
            s_scan, T_scan, h_scan,
            levels=h_levels,
            linewidths=0.8,
            alpha=0.9
        )

        manual_positions = [
            (0.6, 25), (1.0, 55), (1.4, 90), (1.8, 130), (2.3, 175),
            (2.9, 220), (3.5, 265), (4.0, 305), (5.8, 95), (6.3, 145),
            (6.8, 185), (7.2, 220)
        ]
        ax.clabel(
            cs_h,
            inline=True,
            inline_spacing=2,
            fontsize=9,
            fmt=lambda v: f"{v:.0f}",
            manual=manual_positions
        )
    except Exception:
        pass

    # inside-dome isoenthalpy segments
    common_P = sorted(set(byP_liq.keys()) & set(byP_vap.keys()))
    for h0 in h_levels:
        pts = []
        for P_bar in common_P:
            rf = byP_liq[P_bar]
            rg = byP_vap[P_bar]
            hf = float(rf["h_kJ_kg"])
            hg = float(rg["h_kJ_kg"])
            if hf <= h0 <= hg and abs(hg - hf) > 1e-12:
                xq = (h0 - hf) / (hg - hf)
                sf = float(rf["s_kJ_kgK"])
                sg = float(rg["s_kJ_kgK"])
                Tsat = float(rf["T_C"])
                sq = (1.0 - xq) * sf + xq * sg
                pts.append((sq, Tsat))

        if len(pts) >= 2:
            pts = sorted(pts, key=lambda p: p[0])
            ax.plot(
                [p[0] for p in pts],
                [p[1] for p in pts],
                linewidth=0.7,
                alpha=0.55
            )

    ax.text(0.22, 0.86, "h  [kJ/kg]", transform=ax.transAxes, fontsize=15)

    # ------------------------------------------------------------
    # 5) Top pressure axis (support only)
    # ------------------------------------------------------------
    ax_top = ax.twiny()
    ax_top.set_xlim(*xlim)
    ax_top.set_xlabel("p [MPa]")

    if sat_vap:
        map_P_to_s = {float(r["P_bar"]): float(r["s_kJ_kgK"]) for r in sat_vap}
        P_av = sorted(map_P_to_s.keys())
        desired_mpa = [10, 5, 2, 1, 0.5, 0.2, 0.1, 0.05, 0.02, 0.01]

        tick_pos = []
        tick_lab = []

        for p_mpa in desired_mpa:
            p_bar = p_mpa * 10.0
            p_sel = _snap_to_available_log(p_bar, P_av)
            s_tick = map_P_to_s.get(p_sel, None)
            if s_tick is None:
                continue
            if xlim[0] <= s_tick <= xlim[1]:
                tick_pos.append(float(s_tick))
                tick_lab.append(_format_mpa(p_mpa))

        order = np.argsort(tick_pos)
        tick_pos = [tick_pos[i] for i in order]
        tick_lab = [tick_lab[i] for i in order]

        ax_top.set_xticks(tick_pos)
        ax_top.set_xticklabels(tick_lab)

        for i, lbl in enumerate(ax_top.get_xticklabels()):
            lbl.set_fontsize(9)
            if i % 2 == 0:
                lbl.set_y(0.02)
            else:
                lbl.set_y(0.06)

    # ------------------------------------------------------------
    # 6) Final formatting
    # ------------------------------------------------------------
    ax.set_xlabel("s [kJ/kg·K]")
    ax.set_ylabel("T [°C]")
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.grid(True, alpha=0.18)

    if title is None:
        title = os.path.basename(csv_path).replace("_thermo_map.csv", "")
    ax.set_title(f"T–s diagram (readable): {title}")

    plt.tight_layout()

    if png_path:
        os.makedirs(os.path.dirname(os.path.abspath(png_path)), exist_ok=True)
        plt.savefig(png_path, dpi=dpi)
    else:
        plt.show()


if __name__ == "__main__":
    base = os.path.dirname(os.path.abspath(__file__))
    search = os.path.join(base, "..", "..", "**", "*_thermo_map.csv")
    files = glob.glob(search, recursive=True)

    if not files:
        print("No thermo_map.csv files found. Run integration_thermo.py first.")
        raise SystemExit(1)

    latest = max(files, key=os.path.getmtime)
    print("Using thermo map:", latest)

    png = latest.replace("_thermo_map.csv", "_Ts_readable.png")

    plot_ts_readable(
        latest,
        png_path=png,
        figsize=(18, 10),
        dpi=300,
        xlim=(0, 9),
        ylim=(0, 400),
    )

    print("Plot saved:", png)