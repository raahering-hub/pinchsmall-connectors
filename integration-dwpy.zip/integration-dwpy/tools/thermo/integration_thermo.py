from __future__ import annotations

import os
import sys
import json
import argparse
from dataclasses import dataclass
from typing import Dict, List, Any, Optional, Tuple

import numpy as np

# pythoncom is required when using COM on Windows (DWSIM automation)
import pythoncom

# pythonnet: clr allows importing .NET assemblies and DWSIM DLLs
import clr
from System.IO import Directory

# ---------------------------
# Defaults (Run Python File)
# ---------------------------
DEFAULT_CATALOG_YAML = r"Z:\dwsim-python\integration-dwpy\connectors\pinch\Water\Cheese Process\catalog.yaml"
DEFAULT_TMIN_C = 0.0
DEFAULT_TMAX_C = 400.0
DEFAULT_PMIN_BAR = 0.1
DEFAULT_PMAX_BAR = 100.0

# Local DWSIM installation folder containing the required DLLs
DWSIM_PATH = r"C:\DWSIM\\"

# Ensure this script folder is on sys.path (so plot_ts import works if needed)
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

# ---------------------------
# DWSIM bootstrap
# ---------------------------
pythoncom.CoInitialize()
Directory.SetCurrentDirectory(DWSIM_PATH)

clr.AddReference(DWSIM_PATH + "CapeOpen.dll")
clr.AddReference(DWSIM_PATH + "DWSIM.Automation.dll")
clr.AddReference(DWSIM_PATH + "DWSIM.Interfaces.dll")
clr.AddReference(DWSIM_PATH + "DWSIM.GlobalSettings.dll")
clr.AddReference(DWSIM_PATH + "DWSIM.SharedClasses.dll")
clr.AddReference(DWSIM_PATH + "DWSIM.Thermodynamics.dll")

try:
    clr.AddReference(DWSIM_PATH + "DWSIM.Thermodynamics.ThermoC.dll")
except Exception:
    pass

from DWSIM.Interfaces.Enums.GraphicObjects import ObjectType
from DWSIM.Thermodynamics import PropertyPackages
from DWSIM.Automation import Automation3
from DWSIM.GlobalSettings import Settings


# ---------------------------
# Unit conversions
# ---------------------------
def C_to_K(T_C: float) -> float:
    return float(T_C) + 273.15


def bar_to_Pa(P_bar: float) -> float:
    return float(P_bar) * 1e5


# ---------------------------
# Property package factory
# ---------------------------
def create_property_package(pp_name: str):
    name = (pp_name or "").strip().lower()

    if name in ("steamtables", "steam tables", "steam_tables"):
        return PropertyPackages.SteamTablesPropertyPackage()

    if name in ("pengrobinson", "peng-robinson", "pr"):
        return PropertyPackages.PengRobinsonPropertyPackage()

    if name in ("coolprop",):
        return PropertyPackages.CoolPropPropertyPackage()

    raise NotImplementedError(f"Property package '{pp_name}' is not implemented.")


# ---------------------------
# Composition helpers
# ---------------------------
def _normalize(fracs: Dict[str, float]) -> Dict[str, float]:
    tot = sum(float(v) for v in fracs.values())
    if tot <= 0:
        raise ValueError("Composition total must be > 0.")
    return {str(k): float(v) / tot for k, v in fracs.items()}


def _resolve_available_compound_key(sim, requested_name: str) -> str:
    req = (requested_name or "").strip()
    if not req:
        raise ValueError("Empty compound name.")

    if req in sim.AvailableCompounds:
        return req

    keys = list(sim.AvailableCompounds.Keys)
    lower_map = {str(k).strip().lower(): str(k) for k in keys}
    hit = lower_map.get(req.lower())
    if hit:
        return hit

    raise KeyError(
        f"DWSIM compound '{requested_name}' not found in AvailableCompounds. "
        f"Examples: {keys[:30]}"
    )


def _get_mw_kg_kmol(av_comp) -> float:
    for attr in ("Molar_Weight", "MolarWeight", "MolecularWeight", "MW"):
        if hasattr(av_comp, attr):
            return float(getattr(av_comp, attr))
    raise AttributeError("Molecular weight attribute not found on DWSIM compound object.")


def _massfrac_to_molefrac(
    massfrac: Dict[str, float], mw_kg_kmol: Dict[str, float]
) -> Dict[str, float]:
    n = {c: float(massfrac[c]) / float(mw_kg_kmol[c]) for c in massfrac}
    denom = sum(n.values())
    if denom <= 0:
        raise ValueError("Invalid composition: sum(w_i/MW_i) <= 0.")
    return {c: n[c] / denom for c in n}


def _add_pp_and_compounds(sim, dwsim_components: List[str], pp_name: str):
    for comp_name in dwsim_components:
        key = _resolve_available_compound_key(sim, comp_name)
        comp = sim.AvailableCompounds[key]
        sim.SelectedCompounds.Add(comp.Name, comp)

    pp = create_property_package(pp_name)
    sim.AddPropertyPackage(pp)
    sim.SelectedPropertyPackage = pp
    return pp


def apply_massfrac_as_molefrac(sim, stream, massfrac_by_dwsim_key: Dict[str, float]) -> Dict[str, float]:
    w = _normalize(massfrac_by_dwsim_key)

    mw: Dict[str, float] = {}
    for cname in w.keys():
        av = sim.AvailableCompounds[cname]
        mw[cname] = _get_mw_kg_kmol(av)

    x = _massfrac_to_molefrac(w, mw)
    x = _normalize(x)

    ph0 = stream.Phases[0]
    for cname, xi in x.items():
        ph0.Compounds[cname].MoleFraction = float(xi)

    return x


# ---------------------------
# Stream properties
# ---------------------------
def get_stream_props(stream) -> dict:
    T = float(stream.GetTemperature())       # K
    P = float(stream.GetPressure())          # Pa
    h = float(stream.GetMassEnthalpy())      # kJ/kg
    s = float(stream.GetMassEntropy())       # kJ/(kg.K)
    m = float(stream.GetMassFlow())          # kg/s

    vf_obj = stream.GetProp("phaseFraction", "Vapor", None, "", "mole")
    try:
        x_v = float(vf_obj[0])
    except TypeError:
        x_v = float(vf_obj)

    tol = 1e-6
    if x_v <= tol:
        phase = "L"
    elif x_v >= 1.0 - tol:
        phase = "V"
    else:
        phase = "L+V"

    return {
        "temperature_K": T,
        "pressure_Pa": P,
        "massflow_kg_s": m,
        "enthalpy_kJ_kg": h,
        "entropy_kJ_kgK": s,
        "vapor_fraction": x_v,
        "phase": phase,
    }


# ---------------------------
# YAML loader
# ---------------------------
def load_yaml(path: str) -> dict:
    import yaml
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


# ---------------------------
# Thermo session (build once, evaluate many points)
# ---------------------------
@dataclass
class ThermoSession:
    interf: Any
    sim: Any
    ms: Any
    pp_name: str


def build_session_from_catalog(catalog_yaml_path: str) -> Tuple[dict, ThermoSession]:
    cfg = load_yaml(catalog_yaml_path)

    model = cfg.get("model", {}) or {}
    pp_name = str(model.get("property_package", "PengRobinson")).strip()

    dws = cfg.get("dwsim", {}) or {}
    dwsim_components = list(dws.get("components", []))
    component_map = dict(dws.get("component_map", {}))
    if not dwsim_components or not component_map:
        raise ValueError("Missing dwsim.components or dwsim.component_map in catalog.yaml.")

    comp_block = cfg.get("compounds", {}) or {}
    basis = str(comp_block.get("basis", "MASSFRAC")).upper()
    if basis != "MASSFRAC":
        raise NotImplementedError("Only compounds.basis: MASSFRAC is supported in thermo tool.")

    fracs_pinch = {k: float(v) for k, v in comp_block.items() if k != "basis"}

    # Build flowsheet once
    interf = Automation3()
    sim = interf.CreateFlowsheet()
    Settings.SolverMode = 0

    _add_pp_and_compounds(sim, dwsim_components, pp_name)

    # Map pinch -> DWSIM keys
    massfrac_by_dwsim: Dict[str, float] = {}
    for pinch_name, frac in fracs_pinch.items():
        if pinch_name not in component_map:
            raise KeyError(
                f"Component '{pinch_name}' has no mapping in dwsim.component_map. "
                f"Available: {list(component_map.keys())}"
            )
        dwsim_name = str(component_map[pinch_name])
        dwsim_key = _resolve_available_compound_key(sim, dwsim_name)
        massfrac_by_dwsim[dwsim_key] = float(frac)
    massfrac_by_dwsim = _normalize(massfrac_by_dwsim)

    uid = str(cfg.get("uid", "thermo_stream"))
    ms = sim.AddObject(ObjectType.MaterialStream, 50, 50, uid).GetAsObject()
    sim.AutoLayout()

    # Set any massflow (does not affect h,s on mass basis for equilibrium props)
    m_ref = float((cfg.get("reference_flow", {}) or {}).get("massflow_kg_s", 1.0))
    ms.SetMassFlow(float(m_ref))

    # Apply composition once
    apply_massfrac_as_molefrac(sim, ms, massfrac_by_dwsim)

    session = ThermoSession(interf=interf, sim=sim, ms=ms, pp_name=pp_name)
    return cfg, session


def eval_tp(session: ThermoSession, T_C: float, P_bar: float) -> Optional[dict]:
    session.ms.SetTemperature(float(C_to_K(T_C)))
    session.ms.SetPressure(float(bar_to_Pa(P_bar)))

    errors = session.interf.CalculateFlowsheet2(session.sim)
    if errors:
        return None

    props = get_stream_props(session.ms)
    props["T_C"] = float(T_C)
    props["P_bar"] = float(P_bar)
    return props


# ---------------------------
# Grid + refinement
# ---------------------------
def make_grid(Tmin_C: float, Tmax_C: float, Pmin_bar: float, Pmax_bar: float, nT: int, nP: int):
    T_list = np.linspace(Tmin_C, Tmax_C, int(nT))
    P_list = np.logspace(np.log10(Pmin_bar), np.log10(Pmax_bar), int(nP))
    return T_list, P_list


def scan_grid(session: ThermoSession, T_list_C, P_list_bar) -> List[dict]:
    rows: List[dict] = []
    for P_bar in P_list_bar:
        for T_C in T_list_C:
            r = eval_tp(session, float(T_C), float(P_bar))
            if r is None:
                continue
            rows.append({
                "T_C": r["T_C"],
                "P_bar": r["P_bar"],
                "h_kJ_kg": r["enthalpy_kJ_kg"],
                "s_kJ_kgK": r["entropy_kJ_kgK"],
                "x": r["vapor_fraction"],
                "phase": r["phase"],
            })
    return rows


def refine_two_phase(session: ThermoSession, base_rows: List[dict], P_list_bar, tol: float = 1e-3, extra_points: int = 200) -> List[dict]:
    refined = list(base_rows)

    for P_bar in P_list_bar:
        line = [r for r in base_rows if abs(r["P_bar"] - float(P_bar)) < 1e-12]
        if len(line) < 10:
            continue

        line = sorted(line, key=lambda r: r["T_C"])
        T = np.array([r["T_C"] for r in line], dtype=float)
        x = np.array([r["x"] for r in line], dtype=float)

        mask = (x > tol) & (x < 1.0 - tol)
        if not np.any(mask):
            continue

        Tmin = float(T[mask].min())
        Tmax = float(T[mask].max())
        if not np.isfinite(Tmin) or not np.isfinite(Tmax) or Tmax <= Tmin:
            continue

        T_fine = np.linspace(Tmin, Tmax, int(extra_points))
        fine_rows = scan_grid(session, T_fine, [float(P_bar)])
        refined.extend(fine_rows)

    # de-duplicate by (T,P)
    seen = set()
    uniq: List[dict] = []
    for r in refined:
        k = (round(float(r["T_C"]), 6), round(float(r["P_bar"]), 12), round(float(r["s_kJ_kgK"]), 8))
        if k in seen:
            continue
        seen.add(k)
        uniq.append(r)

    return uniq


# ---------------------------
# Saturation + quality lines (to get a "classic" dome)
# ---------------------------
def _find_Tsat_for_pressure(session: ThermoSession, P_bar: float, Tmin_C: float, Tmax_C: float) -> Optional[float]:
    """
    Find saturation temperature Tsat(P) by bisection on vapor fraction.
    Works well for SteamTables + water.
    """
    r_lo = eval_tp(session, Tmin_C, P_bar)
    r_hi = eval_tp(session, Tmax_C, P_bar)
    if r_lo is None or r_hi is None:
        return None

    x_lo = float(r_lo["vapor_fraction"])
    x_hi = float(r_hi["vapor_fraction"])

    # Need to bracket transition x<0.5 to x>0.5 in the search range
    if not (x_lo < 0.5 and x_hi > 0.5):
        return None

    lo, hi = float(Tmin_C), float(Tmax_C)
    for _ in range(35):
        mid = 0.5 * (lo + hi)
        r_mid = eval_tp(session, mid, P_bar)
        if r_mid is None:
            hi = mid
            continue
        x_mid = float(r_mid["vapor_fraction"])
        if x_mid < 0.5:
            lo = mid
        else:
            hi = mid

    return 0.5 * (lo + hi)


def add_saturation_lines(
    session: ThermoSession,
    rows: List[dict],
    P_list_bar: np.ndarray,
    Tmin_C: float,
    Tmax_C: float,
    x_levels: List[float] = [0.0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0],
) -> List[dict]:
    """
    For each pressure:
      1) find Tsat(P)
      2) compute sat liquid (slightly below Tsat) and sat vapor (slightly above Tsat)
      3) build two-phase property points at Tsat using linear mixing in x for h and s
    """
    out = list(rows)
    eps = 0.05  # °C offset around Tsat

    for P_bar in P_list_bar:
        P_bar = float(P_bar)
        Tsat = _find_Tsat_for_pressure(session, P_bar, Tmin_C, Tmax_C)
        if Tsat is None:
            continue

        r_f = eval_tp(session, Tsat - eps, P_bar)  # sat liquid approx
        r_g = eval_tp(session, Tsat + eps, P_bar)  # sat vapor approx
        if r_f is None or r_g is None:
            continue

        hf, sf = float(r_f["enthalpy_kJ_kg"]), float(r_f["entropy_kJ_kgK"])
        hg, sg = float(r_g["enthalpy_kJ_kg"]), float(r_g["entropy_kJ_kgK"])

        for xq in x_levels:
            xq = float(xq)
            hq = (1.0 - xq) * hf + xq * hg
            sq = (1.0 - xq) * sf + xq * sg
            out.append({
                "T_C": float(Tsat),
                "P_bar": float(P_bar),
                "h_kJ_kg": float(hq),
                "s_kJ_kgK": float(sq),
                "x": float(xq),
                "phase": "sat_line",
            })

    # de-duplicate
    seen = set()
    uniq = []
    for r in out:
        k = (
            round(float(r["T_C"]), 4),
            round(float(r["P_bar"]), 12),
            round(float(r["s_kJ_kgK"]), 8),
            round(float(r["x"]), 3),
            str(r.get("phase", "")),
        )
        if k in seen:
            continue
        seen.add(k)
        uniq.append(r)
    return uniq


# ---------------------------
# Save helpers
# ---------------------------
def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def save_csv(rows: List[dict], path: str) -> None:
    import csv
    fields = ["T_C", "P_bar", "h_kJ_kg", "s_kJ_kgK", "x", "phase"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in fields})


def save_json(rows: List[dict], path: str, meta: dict) -> None:
    payload = {"meta": meta, "data": rows}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


# ---------------------------
# Main API
# ---------------------------
def run_thermo_map(
    catalog_yaml_path: str,
    Tmin_C: float,
    Tmax_C: float,
    Pmin_bar: float,
    Pmax_bar: float,
    nT: int = 150,
    nP: int = 20,
    refine: bool = True,
    refine_tol: float = 1e-3,
    refine_points: int = 200,
    add_sat: bool = True,
    out_dir: Optional[str] = None,
) -> dict:
    cfg, session = build_session_from_catalog(catalog_yaml_path)

    T_list, P_list = make_grid(Tmin_C, Tmax_C, Pmin_bar, Pmax_bar, nT=nT, nP=nP)

    base_rows = scan_grid(session, T_list, P_list)
    rows = refine_two_phase(session, base_rows, P_list, tol=refine_tol, extra_points=refine_points) if refine else base_rows

    # Add saturation dome + quality lines for "classic" plot
    if add_sat:
        rows = add_saturation_lines(session, rows, P_list, Tmin_C, Tmax_C)

    if out_dir is None:
        case_dir = os.path.dirname(os.path.abspath(catalog_yaml_path))
        out_dir = os.path.join(case_dir, "results", "thermo")
    ensure_dir(out_dir)

    uid = str(cfg.get("uid", "thermo"))
    csv_path = os.path.join(out_dir, f"{uid}_thermo_map.csv")
    json_path = os.path.join(out_dir, f"{uid}_thermo_map.json")

    meta = {
        "catalog_yaml": os.path.abspath(catalog_yaml_path),
        "uid": uid,
        "property_package": session.pp_name,
        "ranges": {"Tmin_C": Tmin_C, "Tmax_C": Tmax_C, "Pmin_bar": Pmin_bar, "Pmax_bar": Pmax_bar},
        "grid": {"nT": int(nT), "nP": int(nP)},
        "refine": {"enabled": bool(refine), "tol": float(refine_tol), "points": int(refine_points)},
        "saturation_lines": {"enabled": bool(add_sat)},
        "rows": len(rows),
    }

    save_csv(rows, csv_path)
    save_json(rows, json_path, meta)

    return {"meta": meta, "csv": csv_path, "json": json_path}


def main():
    argv = sys.argv[1:]

    # Run Python File: no args
    if len(argv) == 0:
        catalog = DEFAULT_CATALOG_YAML
        print("[INFO] No CLI args provided. Using default catalog.yaml:")
        print("      ", catalog)

        res = run_thermo_map(
            catalog_yaml_path=catalog,
            Tmin_C=DEFAULT_TMIN_C,
            Tmax_C=DEFAULT_TMAX_C,
            Pmin_bar=DEFAULT_PMIN_BAR,
            Pmax_bar=DEFAULT_PMAX_BAR,
            nT=150,
            nP=20,
            refine=True,
            add_sat=True,
        )

        print("[OK] Thermo map generated")
        print("  CSV :", res["csv"])
        print("  JSON:", res["json"])
        return

    ap = argparse.ArgumentParser(description="Generate thermo map (T,P -> h,s,x) from an existing connector catalog.yaml using DWSIM.")
    ap.add_argument("catalog_yaml", help="Path to catalog.yaml of any connector (existing).")
    ap.add_argument("--Tmin_C", type=float, default=DEFAULT_TMIN_C)
    ap.add_argument("--Tmax_C", type=float, default=DEFAULT_TMAX_C)
    ap.add_argument("--Pmin_bar", type=float, default=DEFAULT_PMIN_BAR)
    ap.add_argument("--Pmax_bar", type=float, default=DEFAULT_PMAX_BAR)
    ap.add_argument("--nT", type=int, default=150)
    ap.add_argument("--nP", type=int, default=20)
    ap.add_argument("--no_refine", action="store_true")
    ap.add_argument("--refine_tol", type=float, default=1e-3)
    ap.add_argument("--refine_points", type=int, default=200)
    ap.add_argument("--no_sat", action="store_true")
    ap.add_argument("--out_dir", type=str, default=None)
    args = ap.parse_args()

    res = run_thermo_map(
        catalog_yaml_path=args.catalog_yaml,
        Tmin_C=args.Tmin_C,
        Tmax_C=args.Tmax_C,
        Pmin_bar=args.Pmin_bar,
        Pmax_bar=args.Pmax_bar,
        nT=args.nT,
        nP=args.nP,
        refine=(not args.no_refine),
        refine_tol=args.refine_tol,
        refine_points=args.refine_points,
        add_sat=(not args.no_sat),
        out_dir=args.out_dir,
    )

    print("[OK] Thermo map generated")
    print("  CSV :", res["csv"])
    print("  JSON:", res["json"])


if __name__ == "__main__":
    main()