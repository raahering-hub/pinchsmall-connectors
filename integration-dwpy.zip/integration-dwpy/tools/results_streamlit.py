from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import pandas as pd
from IPython.display import HTML, display


_RUN_ID_RE = re.compile(r"^\d{8}-\d{6}$")  # e.g. 20260204-105944


def _is_run_id(x: Any) -> bool:
    return isinstance(x, str) and bool(_RUN_ID_RE.match(x.strip()))


def composition_mass_string(res: dict) -> str:
    """
    Build a compact composition string from the connector result.

    Supported formats:
    - NEW (flat): {"compounds": {"basis": "...", "H2O": 0.76, ...}}
    - OLD:        {"compounds": {"basis": "...", "values": {...}}}
    - Legacy:     {"dwsim": {"massfrac_mapped_to_dwsim": {...}}}
    """
    comp = res.get("compounds")

    if isinstance(comp, dict) and comp:
        basis = str(comp.get("basis") or "").strip()

        # NEW (flat)
        parts = []
        for k, v in comp.items():
            if k == "basis":
                continue
            if isinstance(v, (int, float)):
                parts.append(f"{k}[{v:.6g}]")
        if basis and parts:
            return f"{basis}:" + "&".join(parts)

        # OLD: {"values": {...}}
        vals = comp.get("values")
        if isinstance(vals, dict) and vals:
            parts = []
            for k, v in vals.items():
                if isinstance(v, (int, float)):
                    parts.append(f"{k}[{v:.6g}]")
            if basis and parts:
                return f"{basis}:" + "&".join(parts)

    # Legacy mapping
    dws = res.get("dwsim")
    if isinstance(dws, dict):
        mf = dws.get("massfrac_mapped_to_dwsim")
        if isinstance(mf, dict) and mf:
            parts = []
            for k, v in mf.items():
                if isinstance(v, (int, float)):
                    parts.append(f"{k}[{v:.6g}]")
            if parts:
                return "MASSFRAC:" + "&".join(parts)

    return ""


def _extract_latest_result(payload: Any) -> dict | None:
    """
    Return the most recent result dict, supporting:
    - payload is list -> last item
    - payload is dict with "result" -> dict or list
    - payload is dict already shaped like a result
    """
    if isinstance(payload, list) and payload:
        return payload[-1] if isinstance(payload[-1], dict) else None

    if isinstance(payload, dict):
        r = payload.get("result")
        if isinstance(r, dict):
            return r
        if isinstance(r, list) and r:
            return r[-1] if isinstance(r[-1], dict) else None

        # Sometimes the file itself is already a "result-like" dict
        if "properties" in payload and "state" in payload:
            return payload

    return None


def _find_human_case_anywhere(obj: Any) -> str | None:
    """
    Search recursively for a human-friendly case string.
    Priority: keys that look like case labels; ignore run-id timestamps.
    """
    preferred_keys = ("case_label", "case_name", "case_title", "case")

    def walk(x: Any) -> list[str]:
        found: list[str] = []
        if isinstance(x, dict):
            # First, check preferred keys in this dict
            for k in preferred_keys:
                v = x.get(k)
                if isinstance(v, str):
                    s = v.strip()
                    if s and not _is_run_id(s) and any(ch.isalpha() for ch in s):
                        found.append(s)

            # Then recurse into values
            for v in x.values():
                found.extend(walk(v))

        elif isinstance(x, list):
            for it in x:
                found.extend(walk(it))

        return found

    candidates = walk(obj)
    return candidates[0] if candidates else None


def _resolve_case(payload: Any, res: dict) -> str:
    """
    Use res["case"] if it's human-friendly.
    If it looks like a run-id timestamp, search elsewhere in the payload.
    """
    case_val = res.get("case")
    if isinstance(case_val, str):
        s = case_val.strip()
        if s and not _is_run_id(s):
            return s

    # If case is a run-id (or missing), try to find a human case name elsewhere
    human = _find_human_case_anywhere(payload)
    if human:
        return human

    # Last resort: show the raw value if present
    if case_val is None:
        return ""
    return str(case_val)


def render_latest_result_table(connectors_root: str | Path) -> None:
    """
    Read connectors/_shared/latest_connector_result.json and display a 1-row HTML table.

    - Hides 'uid'
    - Ensures 'case' is a human-friendly process name when possible
    """
    connectors_root = Path(connectors_root)
    latest_json = connectors_root / "_shared" / "latest_connector_result.json"

    if not latest_json.exists():
        display(HTML("<p><b>No Streamlit result found yet.</b></p>"))
        return

    payload = json.loads(latest_json.read_text(encoding="utf-8"))
    res = _extract_latest_result(payload)

    if not isinstance(res, dict) or not res:
        display(HTML("<p><b>Result file exists, but its format was not recognized.</b></p>"))
        return

    props = res.get("properties") if isinstance(res.get("properties"), dict) else {}
    state = res.get("state") if isinstance(res.get("state"), dict) else {}
    ref = res.get("reference_flow") if isinstance(res.get("reference_flow"), dict) else {}

    row = {
        "connector": res.get("connector"),
        "case": _resolve_case(payload, res),
        "T [K]": state.get("T_K"),
        "P [Pa]": state.get("P_Pa"),
        "ṁ [kg/s]": ref.get("massflow_kg_s"),
        "h [kJ/kg]": props.get("h_kJ_kg"),
        "s [kJ/kg/K]": props.get("s_kJ_kgK"),
        "phase": props.get("phase"),
        "vf": props.get("vapor_fraction"),
        "comp": composition_mass_string(res),
    }

    df = pd.DataFrame([row])
    display(HTML(df.to_html(index=False)))
