from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from IPython.display import HTML, display


def _python_console_exe() -> str:
    """
    Quarto/Jupyter às vezes usa pythonw.exe (sem console).
    Para subprocess, preferimos python.exe.
    """
    py = Path(sys.executable)
    if py.name.lower() == "pythonw.exe":
        py = py.with_name("python.exe")
    return str(py)


def _is_port_open(host: str, port: int, timeout_s: float = 0.4) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout_s):
            return True
    except OSError:
        return False


def _start_streamlit_detached(
    app_py: Path,
    port: int,
    log_file: Path,
    env: dict,
    stdin_file: Path,
    cwd: Optional[Path] = None,
) -> None:
    """
    Start Streamlit in background (Windows detached process),
    logging stdout/stderr to log_file, and feeding stdin with a blank line
    (so Streamlit onboarding email prompt doesn't block).
    """
    py = _python_console_exe()
    cmd = [
        py,
        "-m",
        "streamlit",
        "run",
        str(app_py),
        "--server.port",
        str(port),
        "--server.address",
        "127.0.0.1",
        "--server.headless",
        "true",
        "--browser.gatherUsageStats",
        "false",
        "--logger.level",
        "warning",
    ]

    log_file.parent.mkdir(parents=True, exist_ok=True)
    stdin_file.parent.mkdir(parents=True, exist_ok=True)

    # IMPORTANT: blank stdin to auto-answer Streamlit "Email:" prompt with empty entry
    # Put multiple newlines to be safe.
    if not stdin_file.exists():
        stdin_file.write_text("\n\n\n", encoding="utf-8")

    creationflags = 0
    if os.name == "nt":
        # detached background process, no new console window
        creationflags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP

    with open(log_file, "a", encoding="utf-8") as f_log, open(stdin_file, "r", encoding="utf-8") as f_in:
        f_log.write("=== START STREAMLIT (detached) ===\n")
        f_log.write(f"CWD: {cwd or app_py.parent}\n")
        f_log.write("CMD: " + " ".join(cmd) + "\n\n")
        f_log.flush()

        subprocess.Popen(
            cmd,
            cwd=str(cwd or app_py.parent),
            env=env,
            stdin=f_in,
            stdout=f_log,
            stderr=f_log,
            creationflags=creationflags,
            close_fds=True,
        )


def ensure_streamlit_running(
    connectors_root: Path,
    tools_dir: Path,
    port: int = 8501,
    wait_s: float = 2.5,
) -> tuple[bool, Path]:
    """
    Returns (is_running, log_path).
    Starts Streamlit if not running.
    """
    host = "127.0.0.1"
    log_path = connectors_root / "_shared" / "streamlit_autostart.log"

    if _is_port_open(host, port):
        return True, log_path

    app_py = tools_dir / "app.py"
    if not app_py.exists():
        # don't start, but provide useful log path anyway
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(f"[ERROR] Streamlit app not found: {app_py}\n", encoding="utf-8")
        return False, log_path

    env = os.environ.copy()
    env["PINCH_CONNECTORS_ROOT"] = str(connectors_root)

    # extra safety: same settings via env as well
    env["STREAMLIT_SERVER_HEADLESS"] = "true"
    env["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"

    stdin_file = connectors_root / "_shared" / "streamlit_stdin.txt"

    _start_streamlit_detached(
        app_py=app_py,
        port=port,
        log_file=log_path,
        env=env,
        stdin_file=stdin_file,
        cwd=tools_dir,
    )

    # wait a bit for server to come up
    t0 = time.time()
    while time.time() - t0 < wait_s:
        if _is_port_open(host, port):
            return True, log_path
        time.sleep(0.15)

    return False, log_path


def show_streamlit_access(
    connectors_root: Path,
    tools_dir: Path,
    port: int = 8501,
    show_header: bool = True,
) -> None:
    """
    Renders a button/link to Streamlit, and auto-starts it if needed.
    """
    connectors_root = Path(connectors_root).resolve()
    tools_dir = Path(tools_dir).resolve()

    running, log_path = ensure_streamlit_running(connectors_root, tools_dir, port=port)

    if show_header:
        display(HTML("<h2>Streamlit (calculator)</h2>"))

    # button
    display(
        HTML(
            f"<a href='http://localhost:{port}' target='_blank' "
            "style='display:inline-block;padding:8px 12px;border:1px solid #999;"
            "border-radius:8px;text-decoration:none;'>Open Streamlit</a>"
        )
    )

    status = "RUNNING" if running else "NOT RUNNING"
    color = "#1b5e20" if running else "#b00020"
    display(HTML(f"<p><b>Status:</b> <span style='color:{color}'>{status}</span></p>"))

    if not running:
        # show last lines of log
        tail = ""
        try:
            if log_path.exists():
                lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
                tail = "\n".join(lines[-30:])
        except Exception:
            tail = ""

        display(
            HTML(
                "<details><summary><b>Troubleshooting (click)</b></summary>"
                f"<p>Streamlit did not start. Log file:<br><code>{log_path}</code></p>"
                f"<pre style='white-space:pre-wrap'>{tail.replace('<','&lt;')}</pre>"
                "</details>"
            )
        )
