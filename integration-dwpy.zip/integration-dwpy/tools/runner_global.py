from __future__ import annotations

import json
import importlib.util
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

# We centralize path logic in tools/paths.py, so app.py + runner_global.py + qmd all agree.
from paths import get_connectors_root

# =============================================================================
# Helpers
# =============================================================================
def find_catalogs(connectors_root: Path) -> List[Path]:
    return sorted(connectors_root.rglob("catalog.yaml"))


def load_yaml(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_json(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f) or {}


def load_integration_module_for_catalog(engine: str, catalog_path: Path):
    engine = (engine or "").strip().lower()
    folder = catalog_path.parent
    candidates = [
        folder / f"integration_{engine}.py",
        folder / "integration.py",
    ]
    module_path = next((p for p in candidates if p.exists()), None)
    if module_path is None:
        raise FileNotFoundError(
            f"Integration module not found next to catalog: {catalog_path}"
        )

    unique_name = (
        f"integration_{engine}__{folder.name}__"
        f"{abs(hash(str(folder))) % 10_000_000}"
    )
    spec = importlib.util.spec_from_file_location(unique_name, str(module_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module spec: {module_path}")

    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod, module_path


def pick(d: dict, *paths: tuple) -> Optional[Any]:
    for path in paths:
        cur: Any = d
        ok = True
        for k in path:
            if not isinstance(cur, dict) or k not in cur:
                ok = False
                break
            cur = cur[k]
        if ok and cur is not None:
            return cur
    return None


def make_uid_fallback(cfg: dict, conn: dict) -> str:
    """
    Deterministic fallback UID if cfg['uid'] is missing.
    Uses connector/case + state point. Keeps it stable for lookups.
    """
    connector = (cfg.get("uid") or conn.get("connector") or conn.get("uid") or "UNKNOWN").strip()
    case = (conn.get("case") or "NOCASE").strip()
    pp = (
        (pick(conn, ("property_package",))
         or pick(conn, ("model", "property_package"))
         or cfg.get("model", {}).get("property_package")
         or "NOPP")
    )
    T = pick(conn, ("state", "T_K"))
    P = pick(conn, ("state", "P_Pa"))

    def norm(s: str) -> str:
        return "_".join(str(s).strip().split())

    T_s = f"{float(T):.4f}" if T is not None else "None"
    P_s = f"{float(P):.0f}" if P is not None else "None"
    return f"{norm(connector)}__{norm(case)}__{norm(pp)}__T{T_s}__P{P_s}"


# =============================================================================
# Normalization
# =============================================================================
def normalize_connector_record(conn: dict) -> dict:
    """
    Normalizes the connector JSON produced by run_connector().
    NOTE: uid/engine will be overwritten from catalog.yaml in run_all(),
    because catalog.yaml is the source of truth.
    """
    uid = conn.get("uid")
    connector_name = conn.get("connector") or uid
    case_name = conn.get("case")

    model = conn.get("model", {}) if isinstance(conn.get("model"), dict) else {}
    fluid = model.get("fluid")
    ppkg = model.get("property_package")

    T = pick(conn, ("state", "T_K"))
    P = pick(conn, ("state", "P_Pa"))
    m = pick(conn, ("reference_flow", "massflow_kg_s"))

    h = pick(conn, ("properties", "h_kJ_kg"))
    s = pick(conn, ("properties", "s_kJ_kgK"))
    vf = pick(conn, ("properties", "vapor_fraction"))
    phase = pick(conn, ("properties", "phase"))

    compounds = conn.get("compounds", {})
    if not isinstance(compounds, dict):
        compounds = {}
    compounds_clean = {k: v for k, v in compounds.items() if k != "basis"}

    rec = {
        "uid": uid,
        "connector": connector_name,
        "case": case_name,
        # IMPORTANT: we keep "engine" out of here (set from cfg later)
        "engine": None,
        "fluid": fluid,
        "property_package": ppkg,
        "state": {
            "T_K": float(T) if T is not None else None,
            "P_Pa": float(P) if P is not None else None,
        },
        "reference_flow": {
            "massflow_kg_s": float(m) if m is not None else None,
        },
        "properties": {
            "h_kJ_kg": float(h) if h is not None else None,
            "s_kJ_kgK": float(s) if s is not None else None,
            "vapor_fraction": float(vf) if vf is not None else None,
            "phase": phase,
        },
        "compounds": {
            "basis": compounds.get("basis"),
            "values": compounds_clean,
        },
    }
    return rec


# =============================================================================
# Main runner
# =============================================================================
def run_all(stop_on_error: bool = False) -> List[Dict[str, Any]]:
    # Use shared path resolver (paths.py). Passing __file__ makes it robust even if cwd changes.
    connectors_root = get_connectors_root(start=Path(__file__))

    catalogs = find_catalogs(connectors_root)

    print("=== Running GLOBAL connector database ===")
    print("Connectors root:", connectors_root)
    print(f"Found {len(catalogs)} catalogs\n")

    database: List[Dict[str, Any]] = []

    for cat in catalogs:
        rel = cat.relative_to(connectors_root)
        cfg = load_yaml(cat)

        if cfg.get("mode") != "connector_database":
            continue

        engine_cfg = str(cfg.get("engine", "")).strip().lower()

        try:
            mod, _ = load_integration_module_for_catalog(engine_cfg, cat)
            run_connector = getattr(mod, "run_connector")
            run_connector(str(cat))

            results_dir = cat.parent / "results"
            connector_json = results_dir / "connector.json"
            if not connector_json.exists():
                alt = results_dir / "connector_simple.json"
                if alt.exists():
                    connector_json = alt

            if connector_json.exists():
                conn = load_json(connector_json)
                rec = normalize_connector_record(conn)

                # ------------------------------------------------------------
                # FIX: Always trust catalog.yaml for uid and engine
                # ------------------------------------------------------------
                cfg_uid = cfg.get("uid")
                if cfg_uid is None or str(cfg_uid).strip() == "":
                    cfg_uid = make_uid_fallback(cfg, conn)

                rec["uid"] = cfg_uid

                # keep connector aligned with uid (more robust for lookups)
                rec["connector"] = cfg_uid

                # engine (integration engine) comes from catalog.yaml
                rec["engine"] = cfg.get("engine")

                # if you want fluid from YAML as fallback
                if not rec.get("fluid"):
                    rec["fluid"] = pick(cfg, ("model", "fluid"))

                # if property_package missing, try YAML
                if not rec.get("property_package"):
                    rec["property_package"] = pick(cfg, ("model", "property_package"))

                rec["_paths"] = {
                    "catalog_yaml": str(cat),
                    "connector_json": str(connector_json),
                }

                database.append(rec)

            else:
                # No connector JSON: still include an entry (best-effort)
                cfg_uid = cfg.get("uid")
                if cfg_uid is None or str(cfg_uid).strip() == "":
                    cfg_uid = f"UNKNOWN__{rel.as_posix().replace('/', '__')}"

                database.append(
                    {
                        "uid": cfg_uid,
                        "connector": cfg_uid,
                        "case": None,
                        "engine": cfg.get("engine"),
                        "fluid": pick(cfg, ("model", "fluid")),
                        "property_package": pick(cfg, ("model", "property_package")),
                        "state": {"T_K": None, "P_Pa": None},
                        "reference_flow": {"massflow_kg_s": None},
                        "properties": {
                            "h_kJ_kg": None,
                            "s_kJ_kgK": None,
                            "vapor_fraction": None,
                            "phase": None,
                        },
                        "compounds": {"basis": None, "values": {}},
                        "_warning": "No connector JSON found",
                        "_paths": {"catalog_yaml": str(cat), "connector_json": None},
                    }
                )

        except Exception as e:
            if stop_on_error:
                raise
            print(f"[ERROR] {rel}: {e}")

    database_path = connectors_root / "connector_database.json"
    with open(database_path, "w", encoding="utf-8") as f:
        json.dump(database, f, indent=2, ensure_ascii=False)

    print("Database saved at:", database_path)
    return database


if __name__ == "__main__":
    run_all(stop_on_error=False)