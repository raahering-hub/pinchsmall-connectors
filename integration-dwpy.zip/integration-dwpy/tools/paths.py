from __future__ import annotations

import os
from pathlib import Path


# =============================================================================
# Small utilities
# =============================================================================

def _clean(s: str | None) -> str:
    """
    Basic cleanup for strings coming from environment variables or user input.
    - Converts None -> ""
    - Strips spaces
    - Strips surrounding quotes ( "..." or '...' )
    """
    return (s or "").strip().strip('"').strip("'")


def _resolve_start_dir(
    *,
    start: Path | None = None,
    qmd_path: str | None = None,
) -> Path:
    """
    Decide a good directory to start searching from.

    Priority:
    1) If 'start' is provided: use it.
    2) Else if 'qmd_path' is provided: use the folder of that file (or that folder itself).
    3) Else if QUARTO_DOCUMENT_PATH exists: use the folder of the current .qmd.
    4) Else: use current working directory (cwd).

    We always return a directory Path.
    """
    # 1) explicit start
    if start is not None:
        p = start
        # if user passed a file, start from its folder
        if p.is_file():
            return p.resolve().parent
        return p.resolve()

    # 2) explicit qmd_path
    qp = _clean(qmd_path)
    if qp:
        p = Path(qp)
        if not p.is_absolute():
            p = (Path.cwd() / p).resolve()
        else:
            p = p.resolve()
        # if it's a .qmd file, use its directory; otherwise treat it as a directory
        return p.parent if p.suffix.lower() == ".qmd" else p

    # 3) Quarto provides this env var when rendering
    qp_env = _clean(os.environ.get("QUARTO_DOCUMENT_PATH"))
    if qp_env:
        p = Path(qp_env)
        if not p.is_absolute():
            p = (Path.cwd() / p).resolve()
        else:
            p = p.resolve()
        return p.parent

    # 4) fallback: current working directory
    return Path.cwd().resolve()


# =============================================================================
# Core discovery functions
# =============================================================================

def find_connectors_root(start_dir: Path) -> Path:
    """
    Walk upwards (parent directories) until we find a folder named 'connectors'.

    Example (typical project layout):
        integration-dwpy/
          tools/
          connectors/
          ...

    If you start anywhere inside integration-dwpy/, this will eventually find:
        integration-dwpy/connectors
    """
    start_dir = start_dir.resolve()

    # We check "start_dir" itself and then go up through all parents.
    for p in (start_dir, *start_dir.parents):
        # Case A: the folder itself is named 'connectors'
        if p.name.lower() == "connectors" and p.is_dir():
            return p.resolve()

        # Case B: the folder contains a child folder named 'connectors'
        candidate = p / "connectors"
        if candidate.is_dir():
            return candidate.resolve()

    raise RuntimeError(f"Could not find 'connectors' folder starting from: {start_dir}")


def find_integration_root(start_dir: Path) -> Path:
    """
    Walk upwards until we find the project root, defined as a folder that contains:
      - tools/
      - connectors/

    This is sometimes useful for scripts that need the root folder, not only connectors/.
    """
    start_dir = start_dir.resolve()

    for p in (start_dir, *start_dir.parents):
        tools_dir = p / "tools"
        connectors_dir = p / "connectors"
        if tools_dir.is_dir() and connectors_dir.is_dir():
            return p.resolve()

    raise RuntimeError(
        "Could not find integration root (expected folders 'tools/' and 'connectors/'). "
        f"Start was: {start_dir}"
    )


# =============================================================================
# Public API (what app.py / runner_global.py / qmd should call)
# =============================================================================

def get_connectors_root(
    *,
    start: Path | None = None,
    qmd_path: str | None = None,
    override_env: str = "PINCH_CONNECTORS_ROOT",
    strict_name_check: bool = True,
) -> Path:
    """
    Return the absolute path to the 'connectors' folder.

    Behavior:
    1) If an environment variable override exists (default: PINCH_CONNECTORS_ROOT),
       use it (after validation).
    2) Otherwise, search upwards from a computed start directory.

    Parameters:
    - start:
        Optional Path to start searching from (file or folder).
        If it's a file, we start from its parent folder.
    - qmd_path:
        Optional string path to a .qmd file (or its folder).
        Useful when calling from Quarto.
    - override_env:
        Name of the env var used for overriding connectors root.
    - strict_name_check:
        If True, require that the override path ends with a folder named 'connectors'.
        This prevents accidentally pointing to the wrong folder.
    """
    override = _clean(os.environ.get(override_env))
    if override:
        p = Path(override).expanduser().resolve()
        if not p.is_dir():
            raise RuntimeError(f"{override_env} is set but not a directory: {p}")
        if strict_name_check and p.name.lower() != "connectors":
            raise RuntimeError(f"{override_env} must point to a folder named 'connectors'. Got: {p}")
        return p

    start_dir = _resolve_start_dir(start=start, qmd_path=qmd_path)
    return find_connectors_root(start_dir)


def get_integration_root(
    *,
    start: Path | None = None,
    qmd_path: str | None = None,
) -> Path:
    """
    Convenience helper: returns integration project root (tools/ + connectors/).
    Useful for scripts that need the root folder for other paths.
    """
    start_dir = _resolve_start_dir(start=start, qmd_path=qmd_path)
    return find_integration_root(start_dir)