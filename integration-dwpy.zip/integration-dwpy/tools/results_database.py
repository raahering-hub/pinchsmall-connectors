from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
from IPython.display import HTML, display


def _comp_str(x: Any) -> str:
    """Convert the 'compounds' field into a compact readable string."""
    if not isinstance(x, dict):
        return ""

    basis = (x.get("basis") or "")

    # NEW format: {"basis": "...", "H2O": 0.76, "FAT": 0.23}
    if any(k != "basis" for k in x.keys()):
        parts = []
        for k, v in x.items():
            if k == "basis":
                continue
            if isinstance(v, (int, float)):
                parts.append(f"{k}:{v:.6g}")
            else:
                parts.append(f"{k}:{v}")
        return (f"{basis}|" if basis else "") + ", ".join(parts)

    # OLD format: {"basis": "...", "values": {...}}
    vals = x.get("values")
    if isinstance(vals, dict) and vals:
        parts = []
        for k, v in vals.items():
            if isinstance(v, (int, float)):
                parts.append(f"{k}:{v:.6g}")
            else:
                parts.append(f"{k}:{v}")
        return (f"{basis}|" if basis else "") + ", ".join(parts)

    return str(basis)


def render_connector_database_tables_by_connector(connectors_root: str | Path) -> None:
    """
    Display the connector database grouped by connector.

    One table is shown per connector, listing all associated cases
    (e.g. Evaporation Process, Rivella Process, etc.).
    """
    connectors_root = Path(connectors_root)
    db_json = connectors_root / "connector_database.json"

    if not db_json.exists():
        display(HTML("<p><b>connector_database.json not found.</b></p>"))
        return

    db = json.loads(db_json.read_text(encoding="utf-8"))
    if not isinstance(db, list) or not db:
        display(HTML("<p><b>connector_database.json is empty.</b></p>"))
        return

    df = pd.DataFrame(db)

    # Flatten nested objects
    if "state" in df.columns:
        df = df.join(pd.json_normalize(df["state"]).add_prefix("state.")).drop(columns=["state"])
    if "reference_flow" in df.columns:
        df = df.join(
            pd.json_normalize(df["reference_flow"]).add_prefix("reference_flow.")
        ).drop(columns=["reference_flow"])
    if "properties" in df.columns:
        df = df.join(
            pd.json_normalize(df["properties"]).add_prefix("properties.")
        ).drop(columns=["properties"])
    if "model" in df.columns:
        df = df.join(pd.json_normalize(df["model"]).add_prefix("model.")).drop(columns=["model"])

    # Composition column
    if "compounds" in df.columns:
        df["composition"] = df["compounds"].apply(_comp_str)

    # Columns to display (stable order)
    columns = [
        ("case", "case"),
        ("state.T_K", "T_K"),
        ("state.P_Pa", "P_Pa"),
        ("reference_flow.massflow_kg_s", "m_kg_s"),
        ("properties.h_kJ_kg", "h_kJ_kg"),
        ("properties.s_kJ_kgK", "s_kJ_kgK"),
        ("properties.phase", "phase"),
        ("properties.vapor_fraction", "vapor_fraction"),
        ("composition", "composition"),
    ]

    out = pd.DataFrame()
    for src, dst in columns:
        if src in df.columns:
            out[dst] = df[src]

    # Add connector column separately (used for grouping)
    out["connector"] = df["connector"].fillna("(no connector)")

    # Optional deduplication
    out = out.drop_duplicates()

    # Sort inside each connector table
    sort_inside = [c for c in ["case", "property_package"] if c in out.columns]

    # Render one table per connector
    for connector_name, g in out.groupby("connector", sort=True):
        g2 = g.copy()
        if sort_inside:
            g2 = g2.sort_values(by=sort_inside, kind="stable")

        display(HTML(f"<h3>{connector_name}</h3>"))
        display(HTML(g2.drop(columns=["connector"]).to_html(index=False)))
